package com.shopme.admin.report;

public enum ReportType {
	DAY, MONTH, CATEGORY, PRODUCT
}
